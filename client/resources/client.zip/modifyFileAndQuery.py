import json
import requests
from httpurl import rootUrl


def modifyFile(pname, fname, fcontent, cookies):
    url = rootUrl + "modifyFile"
    payload = {
        "pname": pname,
        "fname": fname,
        "fcontent": fcontent,
    }
    headers = {
        'Cookie': cookies,
    }
    response = requests.request("POST", url, data=payload, headers=headers)
    response = json.loads(response.text)
    if response['state'] == 1:
        return 1  # update file sucessful
    elif response['state'] == 2:
        return -1  # update file fail
    elif response['state'] == 0:
        return -2  # error


def query(op, pno, pname, fname, cookies):
    url = rootUrl + "query"
    payload = {
        "op": op,
        "pno": pno,
        "pname": pname,
        "fname": fname,
    }
    headers = {
        'Cookie': cookies,
    }
    response = requests.request("POST", url, data=payload, headers=headers)
    response = json.loads(response.text)
    if op == 'pro' and response['state'] == 1:
        return response['poject'], response['files']  # query information of project and files
    if op == 'file' and response['state'] == 1:
        return response['file']  # query information of file
    if response['state'] == 2:
        return -1  # query fail
