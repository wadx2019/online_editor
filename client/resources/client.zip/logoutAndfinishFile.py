import json
import requests
from httpurl import rootUrl


def finishFile(pname, fname, cookies):
    url = rootUrl + "finishFile"
    payload = {
        "pname": pname,
        "fname": fname,

    }
    headers = {
        'Cookie': cookies,
    }
    response = requests.request("POST", url, data=payload, headers=headers)
    response = json.loads(response.text)
    if response['state'] == 1:
        return 1  # finish file sucessful
    elif response['state'] == 0:
        return -1  # finish file fail


def logout(username, password, cookies):
    url = rootUrl + "logout"
    payload = {
        "uname": username,
        "upasswd": password,
    }
    headers = {
        'Cookie': cookies,
    }
    response = requests.request("POST", url, data=payload, headers=headers)
    response = json.loads(response.text)
    if response['state'] == 1:
        return 1  # finish file sucessful
    elif response['state'] == 0:
        return -1  # finish file fail
