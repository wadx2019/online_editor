import json
import requests
import os
import pathlib
from httpurl import rootUrl


def creatProject(pname, cookies):
    if not os.path.exists("./Project"):
        os.mkdir("./Project")
    url = rootUrl + "createProject"
    payload = {
        "pname": pname,
    }
    headers = {
        'Cookie': cookies,
    }
    response = requests.request("POST", url, data=payload, headers=headers)
    response = json.loads(response.text)
    if response['state'] == 1:
        if not os.path.exists("./Project/" + pname):
            os.mkdir("./Project/" + pname)
        else:
            return -1  # project exits
        return response['pno']
    if response['state'] == 2:
        return -1  # createProject fail


def createFile(pname, fname, cookies):
    url = rootUrl + "createFile"
    payload = {
        "pname": pname,
        "fname": fname
    }
    headers = {
        'Cookie': cookies,
    }
    response = requests.request("POST", url, data=payload, headers=headers)
    response = json.loads(response.text)
    if response['state'] == 1:
        if not os.path.exists("./Project/" + pname + '/' + fname):
            pathlib.Path('./Project/' + pname + '/' + fname).touch()
            return 1  # createFile success
        else:
            return -1  # file exits

    if response['state'] == 2:
        return -2  # createFile fail
