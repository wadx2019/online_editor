import requests
import json
from httpurl import rootUrl


def register(username, password):
    url = rootUrl + 'register'
    payload = {
        'uname': username,
        'upasswd': password,
    }
    response = requests.request("POST", url, data=payload)
    return json.loads(response.text)


def login(username, password):
    url = rootUrl + 'login'
    payload = {
        "uname": username,
        "upasswd": password,
    }
    headers = {
        'content-type': "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
        'Content-Type': "application/x-www-form-urlencoded",
        'User-Agent': "PostmanRuntime/7.20.1",
        'Accept': "*/*",
        'Cache-Control': "no-cache",
        'Postman-Token': "13c1df2c-697a-4e75-bce3-4646530d1470,fe8e2667-fc67-4ef2-8731-ada44f3b7077",
        'Host': "127.0.0.1:4000",
        'Accept-Encoding': "gzip, deflate",
        'Content-Length': "271",
        'Connection': "keep-alive",
        'cache-control': "no-cache"
    }
    response = requests.request("POST", url, data=payload, headers=headers)
    cookies = requests.utils.dict_from_cookiejar(response.cookies)
    cookies = "session=" + json.dumps(cookies["session"], ensure_ascii=False)
    return json.loads(response.text), cookies

