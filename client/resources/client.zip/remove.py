import json
import requests
from httpurl import rootUrl


def removeProject(pname, cookies):
    url = rootUrl + "removeProject"
    payload = {
        "pname": pname,
    }
    headers = {
        'Cookie': cookies,
    }
    response = requests.request("POST", url, data=payload, headers=headers)
    response = json.loads(response.text)
    if response['state'] == 1:
        return 1  # remove project sucessful
    elif response['state'] == 3:
        return -1  # remove project fail
    elif response['state'] == 2 or response['state'] == 0:
        return -2  # remove project fail


def removeFile(pname, fname, cookies):
    url = rootUrl + "removeFile"
    payload = {
        "pname": pname,
        "fname": fname,

    }
    headers = {
        'Cookie': cookies,
    }
    response = requests.request("POST", url, data=payload, headers=headers)
    response = json.loads(response.text)
    if response['state'] == 1:
        return 1  # remove file sucessful
    elif response['state'] == 0:
        return -1  # remove project fail